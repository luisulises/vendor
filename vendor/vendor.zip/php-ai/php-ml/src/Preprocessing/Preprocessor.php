<?php

declare(strict_types=1);

namespace Phpml\Preprocessing;

use Phpml\Transformer;

interface Preprocessor extends Transformer
{
}
