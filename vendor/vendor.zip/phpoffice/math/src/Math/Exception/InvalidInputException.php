<?php

namespace PhpOffice\Math\Exception;

class InvalidInputException extends MathException
{
}
